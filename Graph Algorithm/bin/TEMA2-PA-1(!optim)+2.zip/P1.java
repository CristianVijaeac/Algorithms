import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;

public class P1 {
	
	static int numNodes;
	static int numEdges;
	static int numMorePaths;
	
	static class Edge implements Comparable<Edge>{
		int start;
		int end;
		long cost;
		
		public Edge(){
			start=0;
			end=0;
			cost=0;
		}
		
		public Edge(int start,int end,long cost){
			this.start=start;
			this.end=end;
			this.cost=cost;
		}
		
		public String toString(){
			
			return "("+" "+this.start+" "+this.end+" "+this.cost+" )";
		}

		@Override
		public int compareTo(Edge node) {
			if (this.cost>=node.cost) return 1;
			if (this.cost<node.cost) return -1;
			return 0;
		}
		
		@Override
		public Edge clone(){
			return new Edge (this.start,this.end,this.cost);
		}
	}
	
	public static int Find(int node,int[] rootVect){
		
		if (rootVect[node] != node)
			rootVect[node]=Find(rootVect[node],rootVect);
		
		return rootVect[node];
		
	}

	public static long minPath(ArrayList<Edge> edges,ArrayList<Integer> nodes,Edge mustEdge){
		
		if (numEdges<=1) return edges.get(0).cost;

		ArrayList<Edge> result=new ArrayList<Edge>();
	
		int[] rootVect = new int[numNodes];
		int[] depths = new int [numNodes];
		
		if (mustEdge.start == -1 && mustEdge.end == -1 && mustEdge.cost == 0){
			for (int i = 0;i < numNodes;i++){
				rootVect[i]=i;
				depths[i]=0;
			}
		}else{
			for (int i=0;i<numNodes;i++){
				if (i==mustEdge.start)
					rootVect[i]=mustEdge.end;
				else
					rootVect[i]=i;
				
				depths[i]=0;
				
			}
			result.add(mustEdge);
		}
		
		int count=0;
		while(count<numEdges || count<numNodes){
			
			Edge edge = edges.get(count);
			
			if (Find(edge.start,rootVect) == Find(edge.end,rootVect)){
				count++;
				continue;
			}
			
			result.add(edge);
			
			int root1 = Find (edge.start,rootVect);
			int root2 = Find (edge.end,rootVect);
			
			if (root1 != root2){
				if (depths[root1]<depths[root2])
					rootVect[root1] = root2;
				else if (depths[root1]>depths[root2])
					rootVect[root2] = root1;
				else
					rootVect[root1] = root2;
					depths[root2] += 1;
			}	
			
			count++;
	
			}
		
		long sum=0;
		
		for (Edge edge2:result){
			sum+=edge2.cost;
		}
	
		
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BufferedReader in = null;
		ArrayList<Integer> nodes = new ArrayList<Integer>();
		ArrayList<Edge> edges = new ArrayList<Edge>();
		ArrayList<Edge> sortedEdges = new ArrayList<Edge>();
		ArrayList<Integer> morePaths = new ArrayList<Integer>();
		ArrayList<Long> result=new ArrayList<Long>();
	
		try {
			in = new BufferedReader(new FileReader("kim.in"));
			String[] aux=in.readLine().split(" ");
			numNodes=Integer.parseInt(aux[0]);
			numEdges=Integer.parseInt(aux[1]);
			numMorePaths=Integer.parseInt(aux[2]);
			
			for(int i=0;i<numNodes;i++){
				nodes.add(i);
			}
			
			for (int i=0;i<numEdges;i++){
				aux=in.readLine().split(" ");
				edges.add(new Edge(Integer.parseInt(aux[0])-1,Integer.parseInt(aux[1])-1,Long.parseLong(aux[2])));
				sortedEdges.add(new Edge(Integer.parseInt(aux[0])-1,Integer.parseInt(aux[1])-1,Long.parseLong(aux[2])));
			}
			
			Collections.sort(sortedEdges);
			
			for (int i=0;i<numMorePaths;i++){
				String tmp=in.readLine();
				morePaths.add(Integer.parseInt(tmp)-1);
			}
			
			result.add(minPath(sortedEdges,nodes,new Edge(-1,-1,0)));
			
			for (int i=0;i<numMorePaths;i++){
				Edge mustEdge=edges.get(morePaths.get(i));
				//System.out.println(edges.get(i));
				result.add(minPath(sortedEdges,nodes,mustEdge));
			}
		
		} catch (IOException e) {
			e.printStackTrace();
		
		} finally {
			if (in != null) {
		
				try {
					in.close();
				
				} catch (IOException e) {

				}
			}
		}
		
		try {
			BufferedWriter bufferedOut = new BufferedWriter( new FileWriter("kim.out"));
			PrintWriter out = new PrintWriter(bufferedOut);
			
			for (int i=0;i<=numMorePaths;i++){	
				//System.out.println(result.get(i));
				out.println(result.get(i));
			}
			out.close();
			bufferedOut.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
