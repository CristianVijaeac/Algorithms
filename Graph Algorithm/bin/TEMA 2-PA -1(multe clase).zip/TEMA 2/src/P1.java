import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;


public class P1 {
	
	public static int Find(int node,int[] rootVect){
		
		if (rootVect[node] != node)
			rootVect[node]=Find(rootVect[node],rootVect);
		
		return rootVect[node];
		
	}

	public static long minPath(Graph g,Edge mustEdge){
		
		ArrayList<Edge> edges=g.cloneEdges();
		edges.sort(new SortEdges());
		
		if (g.numEdges<=1) return edges.get(0).getCost();

		ArrayList<Edge> result=new ArrayList<Edge>();
	
		int[] rootVect = new int[g.numNodes];
		int[] depths = new int [g.numNodes];
		
		if (mustEdge.getStart()==-1 && mustEdge.getEnd()==-1 && mustEdge.getCost()==0){
			for (int i=0;i<g.numNodes;i++){
				rootVect[i]=i;
				depths[i]=0;
			}
		}else{
			for (int i=0;i<g.numNodes;i++){
				if (i==mustEdge.getStart())
					rootVect[i]=mustEdge.getEnd();
				else
					rootVect[i]=i;
				
				depths[i]=0;
				
			}
			result.add(mustEdge);
		}
		
		int count=0;
		while(count<g.numEdges || count<g.numNodes){
			
			Edge edge = edges.get(count);
			
			if (Find(edge.getStart(),rootVect) == Find(edge.getEnd(),rootVect)){
				count++;
				continue;
			}
			
			result.add(edge);
			
			int root1 = Find (edge.getStart(),rootVect);
			int root2 = Find (edge.getEnd(),rootVect);
			
			if (root1 != root2){
				if (depths[root1]<depths[root2])
					rootVect[root1] = root2;
				else if (depths[root1]>depths[root2])
					rootVect[root2] = root1;
				else
					rootVect[root1] = root2;
					depths[root2] += 1;
			}	
			
			count++;
	
			}
		
		int sum=0;
		
		for (Edge edge2:result){
			sum+=edge2.getCost();
		}
	
		
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Graph g=new Graph();

		g.buildGraph("kim0.in");
		
		try {
			BufferedWriter bufferedOut = new BufferedWriter( new FileWriter("kim.out"));
			PrintWriter out = new PrintWriter(bufferedOut);
			
			long result=minPath(g,new Edge(-1,-1,0));
			
			out.print(result);
			out.println();
			
			for (int i=0;i<g.numMorePaths;i++){
				Edge edge=g.getEdges().get(g.getMorePaths().get(i));
				result=minPath(g,edge);	
				out.print(result);
				out.println();
			}
			out.close();
			bufferedOut.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
