
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Graph {

	private ArrayList<Integer> nodes;
	private ArrayList<Edge> edges;
	private ArrayList<Integer> morePaths;
	public boolean isVisited[];
	public int numNodes;
	public int numEdges;
	public int numMorePaths;
	
	public Graph(){
		this.nodes=new ArrayList<Integer>();
		this.edges=new ArrayList<Edge>();
		this.morePaths=new ArrayList<Integer>();
		this.isVisited=new boolean[10];
		this.numNodes=0;
		this.numEdges=0;
		this.numMorePaths=0;
	}
	
	public void addNode(int node){
		nodes.add(node);
	}
	
	public void addEdge(int node1,int node2,long cost){
		edges.add(new Edge(node1,node2,cost));
	}

	public ArrayList<Integer> getNodes() {
		return nodes;
	}

	public ArrayList<Edge> getEdges() {
		return edges;
	}
	
	public ArrayList<Integer> getMorePaths() {
		return morePaths;
	}
	
	public void buildGraph(String filename){
		
		Scanner in=null;
		try {
			in = new Scanner(new File(filename));
		
		
		numNodes=in.nextInt();	//citim numarul de noduri
		//System.out.println(numNodes);
		numEdges=in.nextInt();	//citim numarul de muchii
		//System.out.println(numEdges);
		numMorePaths=in.nextInt();
		//System.out.println(numMorePaths);
		
		isVisited=new boolean[numNodes];
		
		for (int i=1;i<=numNodes;i++){
			isVisited[i-1]=false;
			addNode(i-1);
		}
			
		for (int i=0;i<numEdges;i++){
			int node1=in.nextInt();
			int node2=in.nextInt();
			long cost=in.nextLong();
			addEdge(nodes.get(node1-1),nodes.get(node2-1),cost);
		}
			
		for (int i=0;i<numMorePaths;i++){
			morePaths.add(in.nextInt()-1);
		}
		
		} catch (IOException e) {
			e.printStackTrace();
		
		} finally {
			if (in != null) {
		
				in.close();
			}
		}
	
		
		in.close();
	}
	
	public ArrayList<Edge> cloneEdges(){
		
		ArrayList <Edge> new_list = new ArrayList<Edge>();
		
		for (int i=0;i<numEdges;i++){
			new_list.add(new Edge(this.getEdges().get(i).getStart(),this.getEdges().get(i).getEnd(),this.getEdges().get(i).getCost()));
		}
		
		return new_list;
	}
	
}
