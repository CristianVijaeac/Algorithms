import java.util.Comparator;

public class SortEdges implements Comparator<Edge>{

	@Override
	public int compare(Edge node1,Edge node2) {
		if (node1.getCost()>=node2.getCost()) return 1;
		if (node1.getCost()<node2.getCost()) return -1;
		return 0;
	}

	
	
	
	

}
