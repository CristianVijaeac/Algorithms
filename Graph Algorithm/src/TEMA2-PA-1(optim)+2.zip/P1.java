import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Stack;
import java.util.concurrent.SynchronousQueue;

public class P1 {
	
	static int numNodes;
	static int numEdges;
	static int numMorePaths;
	static long maxCost=Long.MIN_VALUE;
	static long[][] costs=new long[numNodes][numNodes];
	
	static class ParCost {
		
		int parent;
		long cost;
		
		public ParCost(){
			parent=-1;
			cost=0;
		}
		
		public ParCost(int parent,long cost){
			this.parent=parent;
			this.cost=cost;
		}
		
		public String toString(){
			
			return "("+" "+this.parent+" "+this.cost+" )";
		}
	}
	
	
	static class Edge implements Comparable<Edge>{
		int start;
		int end;
		long cost;
		
		public Edge(){
			start=0;
			end=0;
			cost=0;
		}
		
		public Edge(int start,int end,long cost){
			this.start=start;
			this.end=end;
			this.cost=cost;
		}
		
		public String toString(){
			
			return "("+" "+this.start+" "+this.end+" "+this.cost+" )";
		}

		
		@Override
		public int compareTo(Edge node) {
			if (this.cost>=node.cost) return 1;
			if (this.cost<node.cost) return -1;
			return 0;
		}
		
		@Override
		public Edge clone(){
			return new Edge (this.start,this.end,this.cost);
		}
	}
	
	public static int Find(int node,int[] rootVect){
		
		if (rootVect[node] != node)
			rootVect[node]=Find(rootVect[node],rootVect);
		
		return rootVect[node];
		
	}

	public static ArrayList<Long> minPath(ArrayList<Edge> sortedEdges,ArrayList<Integer> nodes,ArrayList<Integer> morePaths,ArrayList<Edge> edges){
		
		ArrayList<Long> result=new ArrayList<Long>();
		Edge first=new Edge();
		boolean[] isVisited = new boolean[numNodes];
		ParCost[][] parentsCost = new ParCost[(int)(Math.log(numNodes)/Math.log(2))][numNodes];
		for (int i=0;i<parentsCost.length;i++)
			for(int j=0;j<numNodes;j++)
				parentsCost[i][j] = new ParCost();
		
	
		if (numEdges<=1) {
			result.add(sortedEdges.get(0).cost);
			for (int i=0;i<numMorePaths;i++)
				result.add(sortedEdges.get(0).cost);
			return result;
		}

		ArrayList<ArrayList<Edge>> path=new ArrayList<ArrayList<Edge>>();
		for (int i=0;i<numNodes;i++)
			path.add(new ArrayList<Edge>());
		
	
		int[] rootVect = new int[numNodes];
		int[] depthsTree = new int [numNodes];
		
		for (int i = 0;i < numNodes;i++){
				rootVect[i]=i;
				depthsTree[i]=0;
		}
		
		
		int count=0;
		while(count<numEdges || count<numNodes){
			
			Edge edge = sortedEdges.get(count);
			
			if (Find(edge.start,rootVect) == Find(edge.end,rootVect)){
				count++;
				continue;
			}
			
			if (count == 0)
				first=edge;
			
			path.get(edge.start).add(new Edge(edge.start,edge.end,edge.cost));
			
			//path.add(new Edge (edge.end,edge.start,edge.cost));
			
			int root1 = Find (edge.start,rootVect);
			int root2 = Find (edge.end,rootVect);
			
			if (root1 != root2){
				if (depthsTree[root1]<depthsTree[root2]){
					rootVect[root1] = root2;
				}
				else if (depthsTree[root1]>depthsTree[root2]){
					rootVect[root2] = root1;
				}
				else{
					rootVect[root1] = root2;
					depthsTree[root1] += 1;
				}
			}	
			
			count++;
	
			}
		
		long sum=0;
		
		for (ArrayList<Edge> node:path){
			for (int i=0;i<node.size();i++)
				sum+=node.get(i).cost;
		}
		
		result.add(sum);
		
		int depthsNodes[] = new int[numNodes];
		
		for (ArrayList<Edge> neighbours : path){
			for (Edge edge : neighbours){
			
				path.get(edge.end).add(new Edge(edge.end,edge.start,edge.cost));
			}
		}
		
		
		dfsParents(path,first.start,isVisited,parentsCost,depthsNodes);
		//System.out.println(path);
		for (int i=1;i<parentsCost.length;i++)
			for(int j=0;j<numNodes;j++)
				if (parentsCost[i-1][j].parent != -1){
					parentsCost[i][j].parent = parentsCost[i-1][parentsCost[i-1][j].parent].parent;
					parentsCost[i][j].cost =  Math.max(parentsCost[i-1][j].cost,parentsCost[i-1][parentsCost[i-1][j].parent].cost);
					
				}

		/*for (int i=0;i<parentsCost.length;i++)
			for(int j=0;j<numNodes;j++)
				System.out.println(parentsCost[i][j].cost);*/
		/*
		for (int i=0;i<numNodes;i++)
			System.out.println(depthsNodes[i]);
		*/
		
		for (ArrayList<Edge> neighbours : path){
			for (Edge edge : neighbours){
				edge.cost=sum;
			}
		}
		
		boolean find;
		for (int i=0;i<numMorePaths;i++){
			find=false;
			Edge edge = edges.get(morePaths.get(i));
			ArrayList<Edge> neighbours = path.get(edge.start);
				for (int j=0;j<neighbours.size();j++){
					if (neighbours.get(j).end == edge.end){
						find=true;
						result.add(neighbours.get(j).cost);
						break;
					}
				}
			if (!find){
				maxCost = Long.MIN_VALUE;
				LCA(edges,edge.start,edge.end,depthsNodes,parentsCost);
			//	System.out.println("Cost adaugat:"+edges.get(morePaths.get(i)).cost+" Cost sters:"+maxCost+" la"+result.get(0));
				//System.out.println("cost:"+maxCost);
				long rez = result.get(0)+edge.cost-maxCost;
				path.get(edge.start).add(new Edge (edge.start,edge.end,rez));
				result.add(rez);
				
			}
		}
		return result;
	}
	
	public static void dfsParents(ArrayList<ArrayList<Edge>> edges,int source,boolean[] isVisited,ParCost[][] parentsCost,int[] depthsNodes){
		/*
		int size = edges.size();
		for (int i=0;i<size;i++)
			edges.add(new Edge(edges.get(i).end,edges.get(i).start,edges.get(i).cost));*/
		
		isVisited[source] = true;
		
		Stack<Integer> s = new Stack<Integer>();
		s.push(source);
		
		while (!s.empty()){
			int node = s.pop();
			//System.out.println(node);
			ArrayList<Edge> neighbours = edges.get(node);
			for (Edge neighbor : neighbours){
					if (!isVisited[neighbor.end]){
						depthsNodes[neighbor.end] =depthsNodes[node]+1;
						isVisited[neighbor.end]=true;
						parentsCost[0][neighbor.end].parent = node; 
						parentsCost[0][neighbor.end].cost = neighbor.cost; 
						s.push(neighbor.end);
					}
				
			}
		}

	}
	
	public static int goUp(ArrayList<Edge> edges,int node,int dist,ParCost[][] parentsCost){
		
		for (int i=0;i<parentsCost.length;i++){
			if ((dist & 1) != 0) {
				if (maxCost<parentsCost[i][node].cost)
					maxCost=parentsCost[i][node].cost;
				
				node = parentsCost[i][node].parent;
				
				//System.out.println(aux);
				
				
			}
			//System.out.println(node);
			dist=dist >> 1;
		}
		//System.out.println("node:"+node+" cost:"+maxCost);
		return node;
	}
	
	public static void LCA (ArrayList<Edge> edges,int node1,int node2,int[] depthsNodes,ParCost parentsCost[][]){
		
		//System.out.println(node1+" "+node2+" "+depthsNodes[node1]+" "+depthsNodes[node2]);
		
		
		if(depthsNodes[node1] > depthsNodes[node2]){
			node1 = goUp (edges,node1,depthsNodes[node1]-depthsNodes[node2],parentsCost);
		}else if (depthsNodes[node1]<depthsNodes[node2]){
			node2 = goUp (edges,node2,depthsNodes[node2]-depthsNodes[node1],parentsCost);
		}
		
		//System.out.println(aux);
		
		if (node1 == node2){
			//System.out.println("node:"+node1+" cost:"+maxCost);
			return;
		}
		
		for (int i=parentsCost.length-1;i>=0;i--){
			if (maxCost<parentsCost[i][node1].cost && parentsCost[i][node2].cost<=parentsCost[i][node1].cost)
				
				maxCost=parentsCost[i][node1].cost;
			else if (maxCost<parentsCost[i][node2].cost &&  parentsCost[i][node1].cost<parentsCost[i][node2].cost)
					maxCost=parentsCost[i][node2].cost;
			
			
				node1 = parentsCost [i][node1].parent;
				node2 = parentsCost [i][node2].parent;
				
				if (node1==node2) break;
				
			}
		
	
		return ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BufferedReader in = null;
		ArrayList<Integer> nodes = new ArrayList<Integer>();
		ArrayList<Edge> edges = new ArrayList<Edge>();
		ArrayList<Edge> sortedEdges = new ArrayList<Edge>();
		ArrayList<Integer> morePaths = new ArrayList<Integer>();
		ArrayList<Long> result=new ArrayList<Long>();
		
		// Get current time
		long start = System.currentTimeMillis();

		// Do something ...

		
	
		try {
			in = new BufferedReader(new FileReader("kim.in"));
			String[] aux=in.readLine().split(" ");
			numNodes=Integer.parseInt(aux[0]);
			numEdges=Integer.parseInt(aux[1]);
			numMorePaths=Integer.parseInt(aux[2]);
			
			
			
			for(int i=0;i<numNodes;i++){
				nodes.add(i);
			}
			
			
			for (int i=0;i<numEdges;i++){
				aux=in.readLine().split(" ");
				edges.add(new Edge(Integer.parseInt(aux[0])-1,Integer.parseInt(aux[1])-1,Long.parseLong(aux[2])));
				sortedEdges.add(new Edge(Integer.parseInt(aux[0])-1,Integer.parseInt(aux[1])-1,Long.parseLong(aux[2])));
			}
			
			Collections.sort(sortedEdges);
			
			for (int i=0;i<numMorePaths;i++){
				String tmp=in.readLine();
				morePaths.add(Integer.parseInt(tmp)-1);
			}
			
			
			result=minPath(sortedEdges,nodes,morePaths,edges);
			
			//dfsParents(edges,0,isVisited,parents);
		
		} catch (IOException e) {
			e.printStackTrace();
		
		} finally {
			if (in != null) {
		
				try {
					in.close();
				
				} catch (IOException e) {

				}
			}
		}
		
		try {
			BufferedWriter bufferedOut = new BufferedWriter( new FileWriter("kim.out"));
			PrintWriter out = new PrintWriter(bufferedOut);
			
			for (int i=0;i<result.size();i++){	
			//	System.out.println(result.get(i));
				out.println(result.get(i));
			}
			out.close();
			bufferedOut.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		// Get elapsed time in milliseconds
		long elapsedTimeMillis = System.currentTimeMillis()-start;

		// Get elapsed time in seconds
		//System.out.println(elapsedTimeMillis/1000F);
	}

}
