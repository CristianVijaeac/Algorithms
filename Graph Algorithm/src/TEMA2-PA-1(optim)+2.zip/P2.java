import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class P2 {
	
	static int numNodes;
	static int numEdges;
	static int minNumIsolated;
	static boolean hasCycle;
	
	public static int DFS(ArrayList<ArrayList<Integer>> edges,int source,boolean[] isVisited,int[] parent){
	
		isVisited[source] = true;
		
		for (int i=0;i<edges.get(source).size();i++){
			int neighbor = edges.get(source).get(i);
			if (!isVisited[neighbor]){
				parent[neighbor] = source;
				minNumIsolated += DFS(edges,neighbor,isVisited,parent);
			}else if (neighbor!=parent[source]){
				hasCycle=true;
				
			}
		}
		if (hasCycle)
			return 0;
		return 1;
	}
	
	public static int minIsolated (ArrayList<Integer> nodes,ArrayList<ArrayList<Integer>> edges,boolean[] isVisited){
		
		int parent[] = new int[numNodes];
		for (int i=0;i<numNodes;i++){
			parent[i]=i;
		}
		
		for (int i=0;i<numNodes;i++){
			if (!isVisited[i]){
				hasCycle = false;
				minNumIsolated += DFS(edges,i,isVisited,parent);			
			}
		}
		return minNumIsolated;
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BufferedReader in = null;
		ArrayList<Integer> nodes = new ArrayList<Integer>();
		ArrayList<ArrayList<Integer>> edges = new ArrayList<ArrayList<Integer>>();
		
		try {
			in = new BufferedReader(new FileReader("portal.in"));
			String[] aux=in.readLine().split(" ");
			numNodes=Integer.parseInt(aux[0]);
			numEdges=Integer.parseInt(aux[1]);
			boolean[] isVisited = new boolean[numNodes];
			for(int i=0;i<numNodes;i++){
				nodes.add(i);
				isVisited[i] = false;
				edges.add(new ArrayList<Integer>());
			}
			
			for (int i=0;i<numEdges;i++){
				aux=in.readLine().split(" ");
				edges.get(Integer.parseInt(aux[0])-1).add(Integer.parseInt(aux[1])-1);
				edges.get(Integer.parseInt(aux[1])-1).add(Integer.parseInt(aux[0])-1);
			}
			
			minNumIsolated = 0;
			
			minIsolated(nodes,edges,isVisited);
		
		} catch (IOException e) {
			e.printStackTrace();
		
		} finally {
			if (in != null) {
		
				try {
					in.close();
				
				} catch (IOException e) {

				}
			}
		}
		
		try {
			BufferedWriter bufferedOut = new BufferedWriter( new FileWriter("portal.out"));
			PrintWriter out = new PrintWriter(bufferedOut);
			
			out.print(minNumIsolated);
			
			out.close();
			bufferedOut.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
